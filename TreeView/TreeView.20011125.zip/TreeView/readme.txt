This is a rewrite of an old package to bring
it up to Java 2 and remove the dependency on
Rogue Wave Software libraries.


OLD README.TXT
--------------

Seventh attempt at coding ClassNode.pm in Java.

This is a Java1.1 version of ITView.

This attempt includes an applet to view the
graph of ClassNode instances.

Uses the JDK and Rogue Wave's JTools,
and uses many features of Java 1.1.

Uses a com.roguewave.tools.BTreeDictionary in
Collector instead of a java.util.Hashtable to
sort nodes out of Collector::KnownNodes(),
Collector::Nodes(), and Collector::TopNodes().

Type:
	% appletviewer ITView.html
to run.

The example reads a tree from the file specified
by the "SOURCE_FILE" parameter to the applet.
It displays it using a instance of the class
GraphicalTree.  Note that the HEIGHT and WIDTH
attributes of the APPLET tag need to be ajusted if
the whole tree is to fit in the Applet's display
area.
